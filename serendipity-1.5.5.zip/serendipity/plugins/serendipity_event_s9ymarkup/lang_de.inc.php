<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Textformatierung: Serendipity');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Standard Serendipity Textformatierung durchf�hren');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Umschlie�ende Sterne heben ein Wort hervor (*wort*), per _wort_ kann ein Wort unterstrichen werden.');
