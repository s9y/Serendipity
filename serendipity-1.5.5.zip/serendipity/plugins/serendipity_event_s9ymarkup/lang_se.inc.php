<?php

/**
 *  @version 
 *  @author Peter Janson <janson.peter@gmail.com>
 *  SE-Revision: Revision of lang_se.inc.php
 */

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Markup: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Applicera grundl�ggande serendipity markup p� inl�ggstext');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Omslutande asterisker markerar text som fetstil (*ord*), understruken text g�rs med hj�lp av _ord_.');

?>
