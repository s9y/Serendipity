<?php # 

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Jo�o P. Matos <jmatos@math.ist.utl.pt>                                 #
# based on the french version by Sebastian Mordziol <argh@php-tools.net> #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Formato: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Activar a formata��o do Serendipity no texto das entradas');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Asteriscos � volta duma palavra (*palavra*) marcam-na como negrito, sublinhados s�o feitos com _palavra_.');

/* vim: set sts=4 ts=4 expandtab : */
?>