<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Formato: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Aplica formato b�sico serendipity a la entrada de texto');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Encerrando entre asteriscos convierte el texto en negrita (*palabra*), el subrayado es hecho as�: _palabra_.');

?>