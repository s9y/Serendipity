<?php # $Id: lang_tn.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', '標記語言： Serendipity');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', '套用基本的 serendipity 標記語言到文章內');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', '星號圍住的文章會以粗體顯示 (*word*)，底線是 _word_。');
?>