<?php # $Id: lang_is.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Textabreyting: Serendipity');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Virkja grunntextabreytingar á texta í færslum');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Að setja texta innan stjarna gerir hann feitletraðan (*orð*), og til að undirstrika setur maður strik niðri á undan og eftir orði (_orð_).');

/* vim: set sts=4 ts=4 expandtab : */
?>