<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_S9YMARKUP_NAME', '마크업: 세렌디피티');
        @define('PLUGIN_EVENT_S9YMARKUP_DESC', '작성한 글에 기본적인 세렌디피티 마크업을 적용함');
        @define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', '*단어* 식으로 단어를 별표로 둘러싸면 진하게 표시되며 밑줄을 치려면 _단어_ 식으로 적으면 됩니다.');

?>
