<?php # $Id: lang_cs.inc.php 1381 2007-11-20 00:00:00Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Vladimir Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Markup: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Provádí základní značkování textu.');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Slova mezi hvězdičkami budou tučná (*tučně*), podtržení podobně pomocí podtržítek _podtržené_.');
