<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Znacznik: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Stosowanie podstawowych znaczników Serendipity do wprowadzonego tekstu');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Zamknięcie tekstu w znakach gwiazdki spowoduje jego wytłuszczenie (*tekst*), podkreślenia są tworzone przez zastosowanie _tekst_.');

?>
