<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_S9YMARKUP_NAME', 'Znacznik: Serendipity');
@define('PLUGIN_EVENT_S9YMARKUP_DESC', 'Stosowanie podstawowych znacznik�w Serendipity do wprowadzonego tekstu');
@define('PLUGIN_EVENT_S9YMARKUP_TRANSFORM', 'Zamkni�cie tekstu w znakach gwiazdki spowoduje jego wyt�uszczenie (*tekst*), podkre�lenia s� tworzone przez zastosowanie _tekst_.');

?>
