<?php # $Id: lang_cs.inc.php 1381 2007-11-20 00:00:00Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Vladimir Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Markup: Smajl�ci');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'P�ev�d� standardn� smajl�ky na grafick� obr�zky');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Standardn� smajl�ci jako :-) nebo ;-) budou p�evedeni na obr�zky.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'P��pona souboru');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'P��pona souboru va�ich emotikon. Rozli�uje velikost p�smen.');
