<?php # $Id: lang_en.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Markup: Emoticate');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'Convert standard emoticons into graphic images');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Standard emoticons like :-) and ;-) are converted to images.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'File extension');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'The file extension of your emoticons. This is case sensitive.');
?>
