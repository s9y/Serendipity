<?php # $Id:$
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details
# Translation (c) by  Jo�o P. Matos <jmatos@math.ist.utl.pt>
# based on spanish version (c) by <rlazo.paz@gmail.com>
/* vim: set sts=4 ts=4 expandtab : */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Formato: Smilies');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'Converter smilies normais em imagens');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Smilies normais como :-) e ;-) s�o convertidos em imagens.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'File extension');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'The file extension of your emoticons. This is case sensitive.');
?>
