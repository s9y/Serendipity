<?php

/**
 *  @version 
 *  @author Peter Janson <janson.peter@gmail.com>
 *  SE-Revision: Revision of lang_se.inc.php
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Markup: Emoticate');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'G�r om standard emoticons till grafiska bilder');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Standard emoticons som :-) och ;-) konverteras till bilder.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'Fil�ndelse');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'Fil�ndelse f�r dina emoticons. Denna �r "case sensitive", dvs se till att skriva stora och sm� bokst�ver r�tt.');

?>
