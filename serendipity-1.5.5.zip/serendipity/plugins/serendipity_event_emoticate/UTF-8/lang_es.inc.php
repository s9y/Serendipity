<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Formato: Smilies');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'Convertir smilies normales en imágenes');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Smilies normales como :-) y ;-) son convertidos en imágenes.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'Extensión del archivo');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'La extensión de tus smiles. Es sensible a mayúsculas/minúsculas.');
?>