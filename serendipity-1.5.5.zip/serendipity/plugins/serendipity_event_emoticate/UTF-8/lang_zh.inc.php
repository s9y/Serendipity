<?php

@define('PLUGIN_EVENT_EMOTICATE_NAME', '标记语言: 表情图案');
@define('PLUGIN_EVENT_EMOTICATE_DESC', '将标准的表示表情色彩的字符串转换成图片形式');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', '像 :-) 和 ;-) 等标准的表示表情色彩的字符串会被转换成图片形式');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', '文件扩展名');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', '图片表情文件的扩展名（区分大小写）');
