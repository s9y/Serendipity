<?php # $Id: lang_bg.inc.php 1419 2006-08-29 10:25:22Z jwalker $

/**
 *  @version $Revision: 1419 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

    @define('PLUGIN_EVENT_EMOTICATE_NAME', 'Форматиране на текст: Усмивки');
    @define('PLUGIN_EVENT_EMOTICATE_DESC', 'Конвертира стандартните знаци за изразяване на емоции в графични изображения');
    @define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Стандартните знаци :) и ;) се конвертират в графични изображения');
    @define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'Разширение на файла');
    @define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'Разширение на файловете за усмивки. Малките и главните букви имат значение.');
