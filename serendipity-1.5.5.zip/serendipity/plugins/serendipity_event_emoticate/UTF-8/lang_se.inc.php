<?php

/**
 *  @version 
 *  @author Peter Janson <janson.peter@gmail.com>
 *  SE-Revision: Revision of lang_se.inc.php
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Markup: Emoticate');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'Gör om standard emoticons till grafiska bilder');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Standard emoticons som :-) och ;-) konverteras till bilder.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'Filändelse');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'Filändelse för dina emoticons. Denna är "case sensitive", dvs se till att skriva stora och små bokstäver rätt.');

?>
