<?php # $Id: lang_en.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author henrik@schack.dk <henrik@schack.dk>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Formatering: Smileys');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'Konverter standard tekst-smileys til billeder');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Standard tekst-smileys som :-) og ;-) konverteres til billeder.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'Filnavnendelse');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'Filnavnendelsen på dine smileys. Der er forskel på store/små bogstaver.');
?>
