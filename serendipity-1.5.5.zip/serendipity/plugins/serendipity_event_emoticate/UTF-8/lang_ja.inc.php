<?php # $Id: lang_ja.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 691
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'マークアップ: 感情表現');
@define('PLUGIN_EVENT_EMOTICATE_DESC', '標準的な感情表現を画像に変換します。');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', '標準的な感情表現、 :-) や ;-) といったものは画像に変換します。');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'File extension');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'The file extension of your emoticons. This is case sensitive.');
/* vim: set sts=4 ts=4 expandtab : */
?>
