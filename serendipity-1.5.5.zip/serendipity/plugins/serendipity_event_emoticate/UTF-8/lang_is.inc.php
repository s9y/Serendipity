<?php # $Id: lang_is.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_EMOTICATE_NAME', 'Textabreyting: Tilfinningavæða');
        @define('PLUGIN_EVENT_EMOTICATE_DESC', 'Breyta venjulegum textabroskörlum í grafískar myndir');
        @define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Venjulegum broskörlum, eins og :-) og ;-), verður breytt í myndir.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'Skráarviðskeyti');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'Skráarviðskeyti broskarklanna. Há- og lágstafir skipta máli.');
/* vim: set sts=4 ts=4 expandtab : */
?>