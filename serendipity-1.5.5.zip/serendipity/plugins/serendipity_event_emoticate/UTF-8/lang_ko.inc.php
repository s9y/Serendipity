<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_EMOTICATE_NAME', '마크업: 이모티콘');
        @define('PLUGIN_EVENT_EMOTICATE_DESC', '표준 이모티콘을 그림으로 바꿈');
        @define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', ':-) 이나 ;-) 와 같은 표준 이모티콘은 그림으로 바뀝니다.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'File extension');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'The file extension of your emoticons. This is case sensitive.');
?>
