<?php # $Id: lang_cs.inc.php 1381 2007-11-20 00:00:00Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Vladimir Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_EMOTICATE_NAME', 'Markup: Smajlíci');
@define('PLUGIN_EVENT_EMOTICATE_DESC', 'Převádí standardní smajlíky na grafické obrázky');
@define('PLUGIN_EVENT_EMOTICATE_TRANSFORM', 'Standardní smajlíci jako :-) nebo ;-) budou převedeni na obrázky.');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION', 'Přípona souboru');
@define('PLUGIN_EVENT_EMOTICATE_EXTENSION_BLAHBLAH', 'Přípona souboru vašich emotikon. Rozlišuje velikost písmen.');
