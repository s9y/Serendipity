<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', 'Creative Commons');
        @define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', 'Zeigt einen Creative Commons Hinweis an');
