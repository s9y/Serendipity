<?php # $Id: lang_ja.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 692
 */

@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', 'クリエイティブコモンズ');
@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', 'サイドバーにクリエイティブコモンズを告示します。');

?>
