<?php

@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', '“创作共用”协议');
@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', '在侧栏显示一条“创作共用”协议的提示。');
