<?php # $Id: lang_cz.inc.php 1381 2007-12-14 00:12:00 VladaAjgl $

/**
 *  @version $Revision: 1381 $
 *  @author Vladimír Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_NAME', 'Creative Commons');
@define('PLUGIN_SIDEBAR_CREATIVECOMMONS_DESC', 'V postranním panelu zobrazuje podrobnosti použité licence "Creative Commons" (Autorská práva)');

?>
