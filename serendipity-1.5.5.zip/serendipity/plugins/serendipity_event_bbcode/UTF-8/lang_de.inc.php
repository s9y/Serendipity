<?php # lang_de.inc.php 1.0 2009-06-03 09:47:51 VladaAjgl $

/**
 *  @version 1.0
 *  @author Konrad Bauckmeier <kontakt@dd4kids.de>
 *  @translated 2009/06/03
 */
        @define('PLUGIN_EVENT_BBCODE_NAME',     'Textformatierung: BBCode');
        @define('PLUGIN_EVENT_BBCODE_DESC',     'BBCode-Formatierung durchführen');
        @define('PLUGIN_EVENT_BBCODE_TRANSFORM', '<a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a>-Formatierung erlaubt');

// Next lines were translated on 2009/06/03
@define('PLUGIN_EVENT_BBCODE_TARGET', 'Benutze target="blank" für Links?');