<?php # $Id: lang_cz.inc.php 1410 2007-12-03 23:40:00 VladaAjgl $

/**
 *  @version $Revision: 1410 $
 *  @author Vladimír Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 *  Translated on 2007-12-03
 */

@define('PLUGIN_EVENT_BBCODE_NAME',         'Markup: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',         'Značkování textu pomocí BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM',    'Povolit (= překládat) značkovací formát <a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a>');
@define('PLUGIN_EVENT_BBCODE_TARGET',       'Použít pro odkazy target="_blank" (odkazy otevírat v novém okně)?');

?>
