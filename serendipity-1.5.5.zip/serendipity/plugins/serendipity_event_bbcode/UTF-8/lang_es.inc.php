<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_BBCODE_NAME',     'Formato: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',     'Dar formato al texto utilizando BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', 'Formato <a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a> permitido');

?>