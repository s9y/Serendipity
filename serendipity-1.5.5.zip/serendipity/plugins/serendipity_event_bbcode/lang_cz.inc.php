<?php # $Id: lang_cz.inc.php 1410 2007-12-03 23:40:00 VladaAjgl $

/**
 *  @version $Revision: 1410 $
 *  @author Vladim�r Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 *  Translated on 2007-12-03
 */

@define('PLUGIN_EVENT_BBCODE_NAME',         'Markup: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',         'Zna�kov�n� textu pomoc� BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM',    'Povolit (= p�ekl�dat) zna�kovac� form�t <a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a>');
@define('PLUGIN_EVENT_BBCODE_TARGET',       'Pou��t pro odkazy target="_blank" (odkazy otev�rat v nov�m okn�)?');

?>
