<?php # $Id:$

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Jo�o P Matos <jmatos@math.ist.utl.pt>                                  #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_BBCODE_NAME',     'C�digo: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',     'Permite usar no texto codifica��o BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', 'Sintaxe <a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a> autorizada');

/* vim: set sts=4 ts=4 expandtab : */
?>
