<?php # $Id: lang_en.inc.php 1410 2006-08-24 09:33:19Z garvinhicking $

/**
 *  @version $Revision: 1410 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_BBCODE_NAME',     'Markup: BBCode');
@define('PLUGIN_EVENT_BBCODE_DESC',     'Markup text using BBCode');
@define('PLUGIN_EVENT_BBCODE_TRANSFORM', '<a href="http://www.phpbb.com/phpBB/faq.php?mode=bbcode">BBCode</a> format allowed');
@define('PLUGIN_EVENT_BBCODE_TARGET',   'Use target="blank" for links?');

?>
