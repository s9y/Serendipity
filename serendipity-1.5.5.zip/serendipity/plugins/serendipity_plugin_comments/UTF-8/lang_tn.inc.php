<?php # $Id: lang_tn.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
##########################################################################
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity    #
# Developer Team) All rights reserved.  See LICENSE file for licensing   #
# details								                                 #
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# (c) 2004-2005 CapriSkye <admin@capriskye.com>                          #
#               http://open.38.com                                       #
##########################################################################

        @define('PLUGIN_COMMENTS_BLAHBLAH', '顯示最新的迴響');
        @define('PLUGIN_COMMENTS_WORDWRAP', '自動換行');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', '要多少字之後自動換行？(預設：30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', '顯示長度');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', '每個迴響要顯示多少個字？(預設：120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', '迴響數量');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', '要顯示多少個迴響？(預設：15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s 發佈於 %s');
?>