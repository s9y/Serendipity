<?php # $Id: lang_bg.inc.php 2348 2008-10-08 19:57:49Z jwalker $

/**
 *  @version $Revision: 2348 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

    @define('PLUGIN_COMMENTS_BLAHBLAH', 'Показва последните коментари на Вашите постинги');
    @define('PLUGIN_COMMENTS_WORDWRAP', 'Пренос на нов ред');
    @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Брой думи преди да сработи преносът на нов ред (по подразбиране: 30)');
    @define('PLUGIN_COMMENTS_MAXCHARS', 'Максимален брой показвани символи за коментар');
    @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Максимум колко символа да бъдат показани за всеки коментар (по подразбиране: 120)');
    @define('PLUGIN_COMMENTS_MAXENTRIES', 'Максимален брой на показваните коментари');
    @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Колко коментара най-много да бъдат показани (по подразбиране: 15)');
    @define('PLUGIN_COMMENTS_ABOUT', '%s за%s');
    @define('PLUGIN_COMMENTS_ANONYMOUS', 'анонимен');

    @define('PLUGIN_COMMENTS_ADDURL', 'Добавя URL към');
