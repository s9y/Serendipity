<?php

@define('PLUGIN_COMMENTS_BLAHBLAH', '显示最新的文章回复');
@define('PLUGIN_COMMENTS_WORDWRAP', '自动换行');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', '在多少个单词之后执行自动换行的操作？(默认：30)');
@define('PLUGIN_COMMENTS_MAXCHARS', '回复长度');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', '每个回复显示多少字符？(默认：120)');
@define('PLUGIN_COMMENTS_MAXENTRIES', '回复数量');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', '显示多少个回复？(默认：15)');
@define('PLUGIN_COMMENTS_ABOUT', '%s 关于 %s');
@define('PLUGIN_COMMENTS_ANONYMOUS', '匿名');
