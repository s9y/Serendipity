<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Wyświetl ostatnie komentarze do wpisów');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Przycinanie komentarza');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Jak wiele słów zostanie pokazanych zanim nastąpi przycięcie komentarza. (Standardowo: 30)');
@define('PLUGIN_COMMENTS_MAXCHARS', 'Maksymalna ilość znaków na komentarz');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Jak wiele znaków zostanie wyświetlonych w każdym komentarzu. (Standardowo: 120)');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'Maksymalna ilość pokazywanych komentarzy');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Jak wiele komentarzy będzie pokazywanych. (Standardowo: 15)');
@define('PLUGIN_COMMENTS_ABOUT', '%s do wpisu%s');
@define('PLUGIN_COMMENTS_ANONYMOUS', 'anonim');
?>
