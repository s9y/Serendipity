<?php # $Id: lang_tr.inc.php 1987 2007-10-18 11:42:35Z garvinhicking $

/**
 *  @version $Revision: 1987 $
 *  @author Ahmet Usal <ahmetusal@gmail.com>
 *  First public version: lang_tr.inc.php
 */

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Yazýlarýnýz hakkýnda bildirilen son görüþlerin gösterimi');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Kelime kaydýrma');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH','Kaç adet kelimeye kadar kelime kaydýrma uygulanmasýn? (Öntanýmlý: 30)');
@define('PLUGIN_COMMENTS_MAXCHARS', 'Görüþ baþýna kullanýlabilecek en çok harf karakteri sayýsý');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Görüþlerde en çok kaç adet harfin kullanýmýna izin verilsin? (Öntanýmlý: 120)');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'En çok görüþ sayýsý');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Kaç adet görüþ gösterilsin? (Öntanýmlý: 15)');
@define('PLUGIN_COMMENTS_ABOUT', '%s hakkýnda%s');

?>
