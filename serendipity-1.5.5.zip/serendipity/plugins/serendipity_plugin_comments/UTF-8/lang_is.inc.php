<?php # $Id: lang_is.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_COMMENTS_BLAHBLAH', 'Sýnir síðustu athugasemdir á færslurnar þínar');
        @define('PLUGIN_COMMENTS_WORDWRAP', 'Línuskil');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Hversu mörg orð þar til línuskil eiga sér stað? (Sjálfgefið gildi: 30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', 'Hámarksstafafjöldi á athugasemd');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Hversu margir stafir eiga að vera birtir fyrir hverja athugasemd? (Sjálfgefið gildi: 120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', 'Hámarksfjöldi athugasemda');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Hversu margar athugasemdir skal sýna? (Sjálfgefið gildi: 15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s um%s');
/* vim: set sts=4 ts=4 expandtab : */
?>