<?php # lang_de.inc.php 1.0 2009-06-03 10:01:36 VladaAjgl $

/**
 *  @version 1.0
 *  @author Konrad Bauckmeier <kontakt@dd4kids.de>
 *  @translated 2009/06/03
 */
        @define('PLUGIN_COMMENTS_BLAHBLAH', 'Zeigt die letzten Kommentare');
        @define('PLUGIN_COMMENTS_WORDWRAP', 'Zeilenumbruch');
        @define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Nach wievielen Buchstaben soll ein Zeilenumbruch eingef�gt werden? (Standard: 30)');
        @define('PLUGIN_COMMENTS_MAXCHARS', 'Zeichen pro Kommentar');
        @define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Wieviele Zeichen sollen pro Kommentar gezeigt werden? (Standard: 120)');
        @define('PLUGIN_COMMENTS_MAXENTRIES', 'Anzahl an Kommentaren');
        @define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Wieviele Kommentare sollen gezeigt werden? (Standard: 15)');
        @define('PLUGIN_COMMENTS_ABOUT', '%s zu%s');

        @define('PLUGIN_COMMENTS_ADDURL', 'Kommentatoren URL anzeigen bei');

// Next lines were translated on 2009/06/03
@define('PLUGIN_COMMENTS_ANONYMOUS', 'anonym');