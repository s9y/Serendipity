<?php # $Id: lang_en.inc.php 2333 2008-09-10 10:26:36Z garvinhicking $

/**
 *  @version $Revision: 2333 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Displays the last comments to your entries');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Wordwrap');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'How many characters until a wordwrap will occur? (Default: 30)');
@define('PLUGIN_COMMENTS_MAXCHARS', 'Maximum chars per comment');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'How many chars will be displayed for each comment? (Default: 120)');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'Maximum number of comments');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'How many comments will be shown? (Default: 15)');
@define('PLUGIN_COMMENTS_ABOUT', '%s about%s');
@define('PLUGIN_COMMENTS_ANONYMOUS', 'anon');

@define('PLUGIN_COMMENTS_ADDURL', 'Add writers URL to');

