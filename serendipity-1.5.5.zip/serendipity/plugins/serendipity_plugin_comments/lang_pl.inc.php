<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Kostas CoSTa Brzezinski <costa@kofeina.net>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Wy�wietl ostatnie komentarze do wpis�w');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Przycinanie komentarza');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', 'Jak wiele s��w zostanie pokazanych zanim nast�pi przyci�cie komentarza. (Standardowo: 30)');
@define('PLUGIN_COMMENTS_MAXCHARS', 'Maksymalna ilo�� znak�w na komentarz');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', 'Jak wiele znak�w zostanie wy�wietlonych w ka�dym komentarzu. (Standardowo: 120)');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'Maksymalna ilo�� pokazywanych komentarzy');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', 'Jak wiele komentarzy b�dzie pokazywanych. (Standardowo: 15)');
@define('PLUGIN_COMMENTS_ABOUT', '%s do wpisu%s');
@define('PLUGIN_COMMENTS_ANONYMOUS', 'anonim');
?>
