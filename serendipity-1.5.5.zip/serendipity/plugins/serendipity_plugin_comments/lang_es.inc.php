<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_COMMENTS_BLAHBLAH', 'Muestra los �ltimos comentarios hechos a tus entradas');
@define('PLUGIN_COMMENTS_WORDWRAP', 'Wordwrap');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH', '�Cuantas palabras deben haber antes de que se haga un salto de l�nea? (Por defecto: 30)');
@define('PLUGIN_COMMENTS_MAXCHARS', 'M�ximo n�mero de caracteres por comentario');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH', '�Cuantos caracteres deben ser mostrados por cada comentario? (Por defecto: 120)');
@define('PLUGIN_COMMENTS_MAXENTRIES', 'M�ximo n�mero de comentarios');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH', '�Cu�ntos comentarios deben ser mostrados? (Por defecto: 15)');
@define('PLUGIN_COMMENTS_ABOUT', '%s acerca%s');
@define('PLUGIN_COMMENTS_ANONYMOUS', 'anon');
?>
