<?php # $Id: lang_cs.inc.php 1381 2008-01-20 01:31:00 VladaAjgl $

/**
 *  @version $Revision: 1381 $
 *  @author Vladim�r Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_COMMENTS_BLAHBLAH',             'Zobrazuje posledn� koment��e u p��sp�vk�');
@define('PLUGIN_COMMENTS_WORDWRAP',             'Zalamov�n� slov');
@define('PLUGIN_COMMENTS_WORDWRAP_BLAHBLAH',    'Po kolika slovech m� b�t text koment��e o��znut? (P�ednastaveno: 30)');
@define('PLUGIN_COMMENTS_MAXCHARS',             'Maxim�ln� po�et znak�');
@define('PLUGIN_COMMENTS_MAXCHARS_BLAHBLAH',    'Kolik znak� bude nanejv�� zobrazeno z ka�d�ho koment��e? (P�ednastaveno: 120)');
@define('PLUGIN_COMMENTS_MAXENTRIES',           'Po�et zobrazen�ch koment���');
@define('PLUGIN_COMMENTS_MAXENTRIES_BLAHBLAH',  'Kolik posledn�ch koment��� bude zobrazeno? (P�ednastaveno: 15)');
@define('PLUGIN_COMMENTS_ABOUT',                '%s k p��sp�vku %s');
@define('PLUGIN_COMMENTS_ANONYMOUS',            'anonym');

@define('PLUGIN_COMMENTS_ADDURL',               'P�idat URL adresu autor� do');
?>
