<?php # $Id: lang_cs.inc.php 1381 2007-12-14 00:27:00 VladaAjgl $

/**
 *  @version $Revision: 1381 $
 *  @author Vladimír Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_TEMPLATEDROPDOWN_NAME',         'Výběr šablony');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC',         'Zobrazuje rozbalovací políčko pro výběr šablony');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',       'Potvrzovací tlačítko?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',  'Zobrazit potvrzovací tlačítko?');

?>
