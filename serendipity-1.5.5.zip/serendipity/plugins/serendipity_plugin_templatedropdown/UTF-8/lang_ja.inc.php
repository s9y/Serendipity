<?php # $Id: lang_ja.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 692
 */

@define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'テンプレートドロップダウン');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'テンプレート変更のボックスを表示します。');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   '送信ボタンの表示は?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   '送信ボタンの表示をしますか?');

/* vim: set sts=4 ts=4 expandtab : */
?>
