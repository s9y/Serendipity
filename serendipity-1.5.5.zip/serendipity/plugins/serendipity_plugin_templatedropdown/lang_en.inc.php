<?php # $Id: lang_en.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'Template dropdown');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'Show a box to change templates');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   'Submit button?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   'Show a submit button?');

?>
