<?php # $Id: lang_cz.inc.php 1381 2007-12-14 00:27:00 VladaAjgl $

/**
 *  @version $Revision: 1381 $
 *  @author Vladim�r Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_TEMPLATEDROPDOWN_NAME',         'V�b�r �ablony');
@define('PLUGIN_TEMPLATEDROPDOWN_DESC',         'Zobrazuje rozbalovac� pol��ko pro v�b�r �ablony');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',       'Potvrzovac� tla��tko?');
@define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',  'Zobrazit potvrzovac� tla��tko?');

?>
