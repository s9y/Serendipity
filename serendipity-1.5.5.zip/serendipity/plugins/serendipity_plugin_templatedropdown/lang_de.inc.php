<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_TEMPLATEDROPDOWN_NAME',     'Template dropdown');
        @define('PLUGIN_TEMPLATEDROPDOWN_DESC',     'Zeigt eine Box um Templates zu �ndern');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT',   'Submit-Button?');
        @define('PLUGIN_TEMPLATEDROPDOWN_SUBMIT_DESC',   'Einen Submit-Button anzeigen?');
