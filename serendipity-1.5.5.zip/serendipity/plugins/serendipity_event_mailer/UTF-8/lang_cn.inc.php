<?php

@define('PLUGIN_EVENT_MAILER_NAME', '使用电子邮件发送文章');
@define('PLUGIN_EVENT_MAILER_DESC', '可以让你将新发布的文章发送到指定的电子邮件地址中');
@define('PLUGIN_EVENT_MAILER_RECIPIENT', '电子邮件收件人');
@define('PLUGIN_EVENT_MAILER_RECIPIENTDESC', '新发布的文章将被发送到这里设置的电子邮件地址(推荐使用邮件列表)');
@define('PLUGIN_EVENT_MAILER_LINK', '在电子邮件内容中包含相关文章的链接？');
@define('PLUGIN_EVENT_MAILER_LINKDESC', '在电子邮件内容中包含相关文章的链接网址');
@define('PLUGIN_EVENT_MAILER_STRIPTAGS', '删除HTML标记语言');
@define('PLUGIN_EVENT_MAILER_STRIPTAGSDESC', '在电子邮件内容中删除HTML标签');
@define('PLUGIN_EVENT_MAILER_CONVERTP', '将HTML段落标签转传成新行');
@define('PLUGIN_EVENT_MAILER_CONVERTPDESC', '在每一个HTML段落后面添加新的一行。如果你启用了“删除HTML标记语言”设置的话，那么启用该设置将很有用，因为它可以保证你的段落格式在电子邮件中不走样（假设你不是手工在文章中添加HTML标记的话）。');
@define('PLUGIN_EVENT_MAILER_RECIPIENTS', '电子邮件收件人 (不同收件人之间使用空格区分)');
@define('PLUGIN_EVENT_MAILER_NOTSENDDECISION', '你决定不将此文章通过电子邮件发送出去，因此该文章没有通过电子邮件发送出去。');
@define('PLUGIN_EVENT_MAILER_SENDING', '电子邮件发送中……');
@define('PLUGIN_EVENT_MAILER_ISTOSENDIT', '使用电子邮件发送文章');