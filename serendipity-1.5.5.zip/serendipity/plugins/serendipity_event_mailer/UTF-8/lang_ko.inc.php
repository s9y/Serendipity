<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_MAILER_NAME', '글을 전자우편으로 발송');
        @define('PLUGIN_EVENT_MAILER_DESC', '새로 작성한 글을 전자우편을 통해 특정 주소로 발송함');
        @define('PLUGIN_EVENT_MAILER_RECIPIENT', '전자우편 수신자');
        @define('PLUGIN_EVENT_MAILER_RECIPIENTDESC', '작성한 글을 발송할 전자우편 주소 (메일링 리스트 권장)');
        @define('PLUGIN_EVENT_MAILER_LINK', '글에 대한 링크 발송');
        @define('PLUGIN_EVENT_MAILER_LINKDESC', '전자우편에 원본 글로 갈 수 있는 링크를 포함시킴');
        @define('PLUGIN_EVENT_MAILER_STRIPTAGS', 'HTML 제거');
        @define('PLUGIN_EVENT_MAILER_STRIPTAGSDESC', '전자우편에서 HTML 태그를 제거함');
        @define('PLUGIN_EVENT_MAILER_CONVERTP', 'HTML 문단을 새 줄로 변환');
        @define('PLUGIN_EVENT_MAILER_CONVERTPDESC', 'HTML 문단이 끝나는 부분에 새 줄을 추가합니다. HTML 제거 기능을 사용할 때 문단 구조를 유지하는데 유용하게 쓸 수 있습니다.');

?>
