<?php # $Id: lang_cz.inc.php 1381 2008-01-20 01:31:00 VladaAjgl $

/**
 *  @version $Revision: 1381 $
 *  @author Vladim�r Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_MAILER_NAME',             'Pos�l�n� p��sp�vk� mailem');
@define('PLUGIN_EVENT_MAILER_DESC',             'Umo��uje pos�lat nov� vytvo�en� p��sp�vky na p�edem zadanou mailovou adresu.');
@define('PLUGIN_EVENT_MAILER_RECIPIENT',        'P��jemce');
@define('PLUGIN_EVENT_MAILER_RECIPIENTDESC',    'E-mailov� adresa, na kterou chcete odeslat p��sp�vek (tip: mailov� konference)');
@define('PLUGIN_EVENT_MAILER_LINK',             'Vlo�it do �l�nku odkaz na p��sp�vek?');
@define('PLUGIN_EVENT_MAILER_LINKDESC',         'Vlo�� do mailu odkaz na p��sp�vek na webu.');
@define('PLUGIN_EVENT_MAILER_STRIPTAGS',        'Odstranit HTML?');
@define('PLUGIN_EVENT_MAILER_STRIPTAGSDESC',    'Odstran� z mailu HTML tagy.');
@define('PLUGIN_EVENT_MAILER_CONVERTP',         'P�ev�st HTML odstavce na nov� ��dky?');
@define('PLUGIN_EVENT_MAILER_CONVERTPDESC',     'P�id�v� pr�zdnou ��dkou za ka�d�m HTML tagem pro odstavec. Pokud zvol�te odstra�ovat HTML tagy, tato volba v�m umo�n� zachovat p�vodn� d�len� na odstavce i v mailu.');
@define('PLUGIN_EVENT_MAILER_RECIPIENTS',       'P��jemce mailu (v�ce p��jemc� odd�lujte ��rkou)');
@define('PLUGIN_EVENT_MAILER_NOTSENDDECISION',  'Tento p��sp�vek nebyl posl�n mailem, proto�e jste se rozhodli ho nepos�lat.');
@define('PLUGIN_EVENT_MAILER_SENDING',          'Pos�l�m');
@define('PLUGIN_EVENT_MAILER_ISTOSENDIT',       'Poslat tento p��sp�vek mailem');
@define('PLUGIN_EVENT_MAILER_SENDTOALL',        'Poslat v�em autor�m');

?>
