<?php # $Id: lang_ko.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
# Translated by: Wesley Hwang-Chung <wesley96@gmail.com> 
# (c) 2005 http://www.tool-box.info/

        @define('PLUGIN_EVENT_WRAPPER_NAME', '이벤트 출력 틀');
        @define('PLUGIN_EVENT_WRAPPER_DESC', '특정 이벤트 플러그인에서 데이터를 모아서 보여줌');
        @define('PLUGIN_EVENT_WRAPPER_PLUGIN', '사용할 이벤트 플러그인');
        @define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', '출력 데이터가 나올 이벤트 플러그인을 선택');
        @define('PLUGIN_EVENT_WRAPPER_TITLEDESC', '옆줄 아이템에 표시될 제목 (이벤트 플러그인의 제목을 그대로 따르려면 비워둠)');

?>
