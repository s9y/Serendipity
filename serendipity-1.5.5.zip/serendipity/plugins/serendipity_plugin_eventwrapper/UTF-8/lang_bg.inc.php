<?php # $Id: lang_bg.inc.php 1419 2006-08-29 10:25:22Z jwalker $

 /**
 *  @version $Revision: 1419 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

    @define('PLUGIN_EVENT_WRAPPER_NAME', 'Обвивка на събитиен плъгин (wrapper)');
    @define('PLUGIN_EVENT_WRAPPER_DESC', 'Показва събраните данни от указан събитиен плъгин');
    @define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Събитиен плъгин източник');
    @define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'Изберете събитиен плъгин, чийто изход трябва да бъде изведен на дисплея');
    @define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Въведете име за страничния плъгин (оставете празно, за да бъде взето името от събитийния плъгин)');
