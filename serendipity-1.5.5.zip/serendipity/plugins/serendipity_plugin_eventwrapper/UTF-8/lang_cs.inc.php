<?php # $Id: lang_cs.inc.php 1381 2007-12-20 00:29:00 VladaAjgl $

/**
 *  @version $Revision: 1381 $
 *  @author Vladimír Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_WRAPPER_NAME',        'Zachytávač výstupu událostí');
@define('PLUGIN_EVENT_WRAPPER_DESC',        'Zobrazuje data shromážděná libovolným pluginem událostí');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN',      'Zdrojový plugin událostí');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC',  'Vyberte plugin událostí, jehož výstup má být zobrazen');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC',   'Vložte nadpis tohoto postranního panelu (pokud je ponecháno prázdné, bude jako nadpis použit název zobrazovaného pluginu)');

?>
