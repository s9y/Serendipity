<?php # $Id: lang_fr.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_WRAPPER_NAME', 'Collecteur de données de plugins');
@define('PLUGIN_EVENT_WRAPPER_DESC', 'Affiche les données générées par un plugin d\'évènement donné.');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Plugin d\'évènement source');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'Sélectionnez le plugin dont les données doivent être affichés');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Entrez le titre de cet élément de barre latérale (laisser vide pour hériter le titre du plugin d\'évènement)');

/* vim: set sts=4 ts=4 expandtab : */
?>