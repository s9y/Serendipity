<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_WRAPPER_NAME', 'Encapsulador de la salida de eventos');
@define('PLUGIN_EVENT_WRAPPER_DESC', 'Muestra información obtenida a través de cierta extensión de evento');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Extensión de evento fuente');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'Selecciona la extensión de evento cuya salida debe ser mostrada');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Ingresa el título para este elemento de la barra lateral (déjalo vacío para heredarlo de la extensión)');

?>
