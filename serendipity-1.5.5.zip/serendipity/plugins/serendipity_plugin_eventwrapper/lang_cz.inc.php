<?php # $Id: lang_cz.inc.php 1381 2007-12-20 00:29:00 VladaAjgl $

/**
 *  @version $Revision: 1381 $
 *  @author Vladim�r Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_WRAPPER_NAME',        'Zachyt�va� v�stupu ud�lost�');
@define('PLUGIN_EVENT_WRAPPER_DESC',        'Zobrazuje data shrom�d�n� libovoln�m pluginem ud�lost�');
@define('PLUGIN_EVENT_WRAPPER_PLUGIN',      'Zdrojov� plugin ud�lost�');
@define('PLUGIN_EVENT_WRAPPER_PLUGINDESC',  'Vyberte plugin ud�lost�, jeho� v�stup m� b�t zobrazen');
@define('PLUGIN_EVENT_WRAPPER_TITLEDESC',   'Vlo�te nadpis tohoto postrann�ho panelu (pokud je ponech�no pr�zdn�, bude jako nadpis pou�it n�zev zobrazovan�ho pluginu)');

?>
