<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_WRAPPER_NAME', 'Event-Ausgabe Wrapper');
        @define('PLUGIN_EVENT_WRAPPER_DESC', 'Zeigt die Ausgabedaten eines Event-Plugins an');
        @define('PLUGIN_EVENT_WRAPPER_PLUGIN', 'Quell Event-Plugin');
        @define('PLUGIN_EVENT_WRAPPER_PLUGINDESC', 'W�hlen Sie das Event-Plugin aus, f�r das die Ausgabe dargestellt werden soll');
        @define('PLUGIN_EVENT_WRAPPER_TITLEDESC', 'Geben Sie den Titel f�r die Sidebar an. Die Eingabe eines leeren Titels zeigt den des Event-Plugins an.');
