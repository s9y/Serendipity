<?php # lang_cz.inc.php 1381.0 2009-03-08 17:14:57 VladaAjgl $

/**
 *  @version 1381.0
 *  @author Vladim�r Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 *  @author Vladim�r Ajgl <vlada@ajgl.cz>
 *  @revisionDate 2009/03/08
 */

@define('PLUGIN_EVENT_TEXTWIKI_NAME',		'Markup: Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_DESC',		'P�ev�d� zna�ky Text_Wiki do HTML');
@define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM',		'Pou�it� zna�ek <a href="http://c2.com/cgi/wiki">Wiki</a> je povoleno');

