<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_TEXTWIKI_NAME',     'Textformatierung: Wiki');
        @define('PLUGIN_EVENT_TEXTWIKI_DESC',     'Wiki-Formatierung durchführen');
        @define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', '<a href="http://c2.com/cgi/wiki">Wiki</a>-Formatierung erlaubt');
