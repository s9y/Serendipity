<?php # $Id: lang_pl.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Translator Name <yourmail@example.com>
 *  EN-Revision: Revision of lang_en.inc.php
 */

@define('PLUGIN_EVENT_TEXTWIKI_NAME',     'Znacznik: Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_DESC',     'Stosuj w tekście znaczniki Text_Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', '<a href="http://c2.com/cgi/wiki">Wiki</a> format dozwolony');

?>
