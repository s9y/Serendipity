<?php # $Id: lang_es.inc.php 1381 2006-08-15 10:14:56Z elf2000 $
/**
 *  @version $Revision: 1381 $
 *  @author Rodrigo Lazo Paz <rlazo.paz@gmail.com>
 *  EN-Revision: 690
 */


@define('PLUGIN_EVENT_TEXTWIKI_NAME',     'Formato: Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_DESC',     'Dar formato al texto utilizando Text_Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', 'Formato <a href="http://c2.com/cgi/wiki">Wiki</a> permitido');

?>