<?php

@define('PLUGIN_EVENT_TEXTWIKI_NAME',     '标记语言：Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_DESC',     '使用Text_Wiki标记相关文字内容');
@define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', '允许使用<a href="http://c2.com/cgi/wiki">Wiki</a>格式。');
