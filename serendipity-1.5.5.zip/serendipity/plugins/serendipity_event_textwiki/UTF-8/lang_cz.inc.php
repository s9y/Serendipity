<?php # lang_cz.inc.php 1381.0 2009-03-08 17:14:57 VladaAjgl $

/**
 *  @version 1381.0
 *  @author Vladimír Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 *  @author Vladimír Ajgl <vlada@ajgl.cz>
 *  @revisionDate 2009/03/08
 */

@define('PLUGIN_EVENT_TEXTWIKI_NAME',		'Markup: Wiki');
@define('PLUGIN_EVENT_TEXTWIKI_DESC',		'Převádí značky Text_Wiki do HTML');
@define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM',		'Použití značek <a href="http://c2.com/cgi/wiki">Wiki</a> je povoleno');

