<?php # $Id: lang_bg.inc.php 1419 2006-08-29 10:25:22Z jwalker $

/**
 *  @version $Revision: 1419 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

    @define('PLUGIN_EVENT_TEXTWIKI_NAME',     'Форматиране на текст: Wiki');
    @define('PLUGIN_EVENT_TEXTWIKI_DESC',     'Форматиране на текст чрез Text_Wiki конвертор');
    @define('PLUGIN_EVENT_TEXTWIKI_TRANSFORM', 'Форматиране <a href="http://c2.com/cgi/wiki">Wiki</a> е разрешено');
