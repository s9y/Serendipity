<?php # $Id: lang_cs.inc.php 1381 2007-11-30 10:10:00 VladaAjgl $

/**
 *  @version $Revision: 1381 $
 *  @author Vladimir Ajgl <vlada@ajgl.cz>
 *  EN-Revision: Revision of lang_en.inc.php
 *  Translated on 2007-11-30
 */

@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Kompatibilita nap��� prohl�e�i');
@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Pou��v� r�zn� (CSS) metody, aby zajistil nejvy��� mo�nou kompatibilitu v r�zn�ch prohl�e��ch (IE, Mozilla, Opera,...).');

?>
