<?php # $Id: lang_ja.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

/**
 *  @version $Revision: 1381 $
 *  @author Tadashi Jokagi <elf2000@users.sourceforge.net>
 *  EN-Revision: 690
 */

@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'ブラウザーの互換性');
@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', '異なる方法(CSS) を用いて最大限にブラウザーの互換性を強化します。');

?>
