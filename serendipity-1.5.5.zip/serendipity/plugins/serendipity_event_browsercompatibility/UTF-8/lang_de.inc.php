<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Browser-Kompatibilität');
        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Wendet verschiedene (CSS) Methoden an, um maximale Browserkompatibilität zu erreichen');
