<?php # $Id: lang_bg.inc.php 1419 2006-08-29 10:25:22Z jwalker $

/**
 *  @version $Revision: 1419 $
 *  @author Ivan Cenov jwalker@hotmail.bg
 */

        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Съвместимост с браузърите');
        @define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Използване на различни (CSS) методи за осигуряване на максимална съвместимост с браузърите');
