<?php # $Id: lang_fr.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

##########################################################################
# serendipity - another blogger...                                       #
##########################################################################
#                                                                        #
# (c) 2003 Jannis Hermanns <J@hacked.it>                                 #
# http://www.jannis.to/programming/serendipity.html                      #
#                                                                        #
# Translated by                                                          #
# Sebastian Mordziol <argh@php-tools.net>                                #
# http://sebastian.mordziol.de                                           #
#                                                                        #
##########################################################################

@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_TITLE', 'Compatibilit� de navigateurs');
@define('PLUGIN_EVENT_BROWSERCOMPATIBILITY_DESC', 'Utilise diff�rentes m�thodes (CSS) pour assurer une compatibilit� maximum avec le plus de navigateurs possibles.');

/* vim: set sts=4 ts=4 expandtab : */
?>