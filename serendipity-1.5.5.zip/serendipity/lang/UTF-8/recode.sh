#!/bin/bash
cp ../*.php .
php recode.php