<?php # $Id: serendipity_config.inc.php 861 2006-01-23 09:46:13Z garvinhicking $
# Copyright (c) 2003-2005, Jannis Hermanns (on behalf the Serendipity Developer Team)
# All rights reserved.  See LICENSE file for licensing details
# Serendipity is provided in managed mode here

#@define('S9Y_INCLUDE_PATH', 's9y/');
@define('S9Y_DATA_PATH', dirname( __FILE__)."/");
require_once 's9y/serendipity_config.inc.php';
/* vim: set sts=4 ts=4 expandtab : */
?>
